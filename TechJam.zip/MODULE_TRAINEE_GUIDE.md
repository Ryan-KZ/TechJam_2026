# Module 2: Venue Operations Intelligence
## "The Halftime Meltdown" — Meridian Stadium Scenario

**Duration:** ~30 minutes  
**Objective:** Use Kaizen to investigate a live crowd analytics anomaly, trace it across multiple data sources, and brief the ops director before the third quarter starts.

---

## SCENARIO BRIEF

You're the Operations Intelligence Analyst for Meridian Stadium. It's halftime of the Week 3 home game — biggest crowd of the season so far. Your phone buzzes: the WaitTime crowd analytics system has flagged a critical alert on the Section 114 concourse. Hot dog carts are showing 30+ people in line and climbing. Meanwhile, the burger stand one level up is practically empty.

The ops director is in the suite. She wants to know what's happening and whether you're losing money — before the third quarter kicks off.

Your mission: Figure out what broke, why the lines diverged so dramatically, put a dollar figure on the damage, and hand her a report she can act on.

**Upload these files to get started:**
- `waittime_sensor_feed.json` — Live crowd analytics snapshot from all concourse sensors
- `waittime_historical_queues.csv` — Queue data from the last 3 home games
- `waittime_pos_sales.csv` — Sales transactions by stand and period
- `waittime_staffing.csv` — Scheduled and actual staffing by stand
- `waittime_supply_inventory.csv` — Inventory levels and equipment status
- `waittime_fan_feedback.csv` — Fan ratings and comments submitted during the game

---

## PHASE 1: WHAT'S HAPPENING RIGHT NOW? (5 min)

**Goal:** Get your bearings. Understand the live state of the venue before digging into history.

### Starting Point
Upload all six data files, then start with a big-picture look at what the sensors are showing right now.

### Sample Prompts

**The quick overview:**
> I just got a crowd analytics alert at our stadium. Take a look at the live sensor data and tell me what's going on — which food stands are slammed right now and which ones have no line? Give me a ranked list so I can see the worst to best at a glance.

**If you want a visual right away:**
> Pull up the live sensor data and make me a bar chart showing wait times across all the food stands right now. I want to see the problem visually.

**Going straight at the anomaly:**
> Something's off on the concourse. The hot dog area is getting flagged but the burger stand nearby seems fine. Show me a side-by-side comparison of those two and tell me how different they actually are.

### What You Should Find
- Section 114 hot dog carts: **34 and 31 people in line**, wait times over 10 minutes, hitting 97th and 88th percentile
- Section 214 burger stands: **8 and 6 people in line**, under 3 minutes, sitting at 17th–23rd percentile
- Both areas are on the same concourse level serving the same crowd
- **This gap shouldn't exist.** Something is causing one area to back up while the other cruises.

---

## PHASE 2: IS THIS NORMAL FOR HALFTIME? (5–7 min)

**Goal:** Rule out "it's just a busy halftime." Compare today's lines to what you've seen in previous games.

This step matters. If the hot dog stand always gets crushed at halftime, that's a different problem than something going wrong today specifically.

### Sample Prompts

**The baseline check:**
> How does today's halftime line at the hot dog stand compare to the last couple of games? Is this normal or is something different happening today?

**Looking for the divergence:**
> Show me a chart comparing the hot dog stand versus the burger stand at halftime across all three home games this season. Has the gap between them always been this big, or is today different?

**Zooming out across the whole game:**
> Plot queue depth over time for both the hot dog and burger areas across every game we have data for. I want to see all the periods — pre-game, each quarter, halftime — so I can spot any pattern.

### What You Should Find
- Games 1 and 2 at halftime: hot dogs ran ~26–28 people, burgers ran ~21–24 — **roughly neck and neck**
- Today: hot dogs at 34 (a new high), burgers at only 8 — **the gap is unprecedented**
- The hot dog line spiked 34% above its previous worst. The burger line dropped 65% below baseline.
- This is **not normal halftime demand**. Something changed today at one or both stands.

---

## PHASE 3: ARE WE LOSING MONEY? (5–7 min)

**Goal:** Translate the queue problem into a revenue number. Give the ops director something concrete.

A long line isn't just a fan experience problem — it means people give up and walk away without spending. Let's see if that's happening.

### Sample Prompts

**The revenue gut check:**
> Pull up the sales data and tell me how many transactions the hot dog stand has done this halftime compared to previous games. Is the line hurting our revenue?

**Comparative analysis:**
> Compare what both the hot dog and burger stands have sold at halftime across all three games. Make me a bar chart. Is today's hot dog halftime an outlier?

**Connecting queues to cash:**
> Today the hot dog stand had over 30 people in line but only processed 118 transactions. Last game with a similar crowd they did 188. Walk me through what that gap means in dollars.

### What You Should Find
- Hot dog halftime transactions: Game 1 = 201, Game 2 = 188, **today = 118** — a **41% drop**
- Hot dog halftime revenue: Game 1 = $2,009, Game 2 = $1,880, **today = $1,062**
- That's **roughly $850–$950 in lost halftime revenue** from one stand, one period
- Burger stand halftime revenue: steady across all three games at ~$2,700–$2,900 — unaffected
- The hot dog stand has a throughput problem, not a demand problem — the line is long *because it's moving slowly*, not because more people showed up

---

## PHASE 4: WHO WAS WORKING? (5 min)

**Goal:** Find out if staffing was a factor.

### Sample Prompts

**The staffing check:**
> Look at the staffing data for today's game. Was the hot dog stand in Section 114 fully staffed at halftime? Did anyone not show up?

**Comparing to past games:**
> Was there a supervisor present at the Section 114 hot dog stand during today's halftime? How does that compare to Games 1 and 2?

**Side-by-side:**
> Show me a staffing comparison between the hot dog stand and the burger stand for today's halftime — scheduled vs. actual staff, supervisor presence, any notes.

### What You Should Find
- Section 114 hot dogs today: **3 staff scheduled, only 2 showed**. Supervisor was **absent** — pulled to assist elsewhere.
- Section 214 burgers today: Full staff, supervisor present, extra prep completed during Q1.
- This is a **contributing factor** but probably not the whole story. One missing staffer wouldn't usually create a 34-person queue on its own.
- The missing supervisor is a flag — no one was there to escalate or improvise when something went wrong.

---

## PHASE 5: WHAT ACTUALLY BROKE? (5 min)

**Goal:** Find the root cause. This is where it clicks.

### Sample Prompts

**The equipment angle:**
> Check the inventory and equipment data for today's game. Is there anything wrong with the hot dog stand's equipment or supply chain? Any failures or delays logged?

**Comparing the two stands:**
> Why is the burger stand running smoothly while the hot dog stand is backed up? Look at everything — inventory levels, equipment status, restocking — and tell me what's different between them today.

**Narrowing in:**
> Was there any supply or equipment issue at the Section 114 hot dog stand specifically during halftime? Show me any status flags or incident notes.

### What You Should Find
- **Section 114, today's halftime: Cheese sauce warming unit failed at 14:08.** Cheese sauce unavailable. Restock runner was delayed 14 minutes reaching the stand.
- The equipment failure slowed every single transaction — customers waiting for a topping that wasn't available, staff improvising, serve time ballooning.
- Section 214 burgers: Extra patties pre-staged during Q1, zero equipment issues, business as usual.
- **This is the smoking gun.** Equipment failure → slower serve time → queue builds → supervisor not there to escalate → staff member already missing → situation spirals.

---

## PHASE 6: WHAT ARE FANS SAYING? (3–5 min)

**Goal:** Validate everything you've found with real fan voices — and find out if people left the line without spending.

### Sample Prompts

**The sentiment check:**
> Look at the fan feedback from today's game. Are people at Section 114 happy or frustrated? How does their sentiment compare to the burger stand?

**Finding the walk-aways:**
> Are any fans specifically mentioning the hot dog line today? Look for comments about wait times, leaving the line, or going somewhere else. Show me the quotes.

**The rating spike:**
> How many 1-star or 2-star reviews did we get from the hot dog area today versus previous games? Make a quick chart — is today a spike in bad ratings?

### What You Should Find
- Section 114 today: **6 reviews, average 1.67 out of 5**. Comments specifically mention 20+ minute waits, the broken cheese sauce warmer, being short-staffed, and fans abandoning the line entirely.
- Section 214 today: 2 reviews, **average 5.0 out of 5**. Fans are raving — and several mention they came *specifically because they fled the hot dog line*.
- At least one confirmed revenue abandonment: a fan explicitly said they waited, gave up, and spent $0.
- The burger stand's steady transaction volume is partially **diverted demand from the Section 114 meltdown** — not organic growth.

---

## PHASE 7: CONNECT ALL THE DOTS (5 min)

**Goal:** Build one coherent story that links every data source. This is your briefing to the director.

### Sample Prompts

**The full picture:**
> Pull everything together for me — the queue data, the sales drop, the staffing gap, the equipment failure, and the fan feedback. What's the complete story of what happened at Section 114 today, in order, and what did it cost us?

**Make it visual:**
> Create a summary table comparing the hot dog stand vs. the burger stand across every dimension we looked at — queue depth, revenue, staffing, equipment, fan rating. I want the anomaly to be obvious at a glance.

**The causal chain:**
> Walk me through the chain of events: what failed first, what happened next, and how it all compounded into a 34-person line and $900 in lost revenue. Step by step.

### The Full Picture

| | Section 114 — Hot Dogs | Section 214 — Burgers |
|---|---|---|
| Queue at halftime | 34 people (97th percentile) | 8 people (17th percentile) |
| Wait time | 10+ minutes | Under 3 minutes |
| Halftime transactions | 118 (↓41% vs. prior games) | 174 (on baseline) |
| Halftime revenue | $1,062 (↓~$880 lost) | $2,784 (stable) |
| Staff scheduled / actual | 3 scheduled / 2 showed | 2 / 2 |
| Supervisor present | ❌ No | ✅ Yes |
| Equipment status | ⚠️ Warmer offline at 14:08 | ✅ All clear |
| Fan rating today | 1.67 / 5 | 5.0 / 5 |

**What happened, step by step:**
1. Cheese sauce warming unit fails silently at 14:08 — nobody notices immediately
2. Serve time per customer creeps up as staff improvise without the warmer
3. One scheduled staff member doesn't show — already down a person going into the crunch
4. Supervisor gets pulled to help the bar stand — no one left to escalate or make a call
5. Halftime rush hits a stand running slower than normal with one fewer person and no supervisor
6. Queue hits 34 people. Fans start seeing the line and giving up.
7. $880+ in halftime revenue evaporates. 1-star reviews start rolling in.
8. Meanwhile, the burger stand — fully staffed, pre-staged, all equipment green — sails through halftime and absorbs some of the overflow crowd.

---

## PHASE 8: BRIEF THE DIRECTOR (3–5 min)

**Goal:** Turn everything you found into a clean PDF report the ops director can read in 5 minutes and act on immediately.

### Sample Prompts

**The urgent brief:**
> I need to brief my ops director before third quarter. Build me a PDF incident report on what happened at Section 114 today — cover what the data showed, what caused it, what it cost, and what we need to fix before the next home game. Keep it sharp enough that she can get through it in 5 minutes.

**With the visuals included:**
> Generate a PDF report on the Section 114 halftime incident. Include the queue comparison chart, the revenue bar chart, the side-by-side summary table, and your recommendations. Make it professional enough to go to leadership.

### What the Report Should Cover
1. **Executive Summary** — One paragraph: what happened, what it cost, what to do
2. **Timeline of the Incident** — From warmer failure at 14:08 through queue peak
3. **Revenue Impact** — $880+ lost at halftime; projected season impact if repeated
4. **Root Cause Analysis** — Equipment failure compounded by staffing gaps
5. **Fan Sentiment** — 1.67-star average, confirmed walk-aways, reputational risk
6. **7 Recommended Actions** for the ops director:
   - Inspect and repair the cheese sauce warming unit before next home game
   - Pre-game equipment checklist completed 90 minutes before gates open (not at open)
   - No-show contingency: defined backup coverage protocol when staff don't arrive
   - Supervisors cannot leave a stand during peak service without a named replacement on-site
   - Add digital wayfinding signage routing fans to Section 214 when Section 114 wait exceeds threshold
   - Pre-stage backup topping options at each stand so a single equipment failure doesn't halt service
   - Configure WaitTime to auto-alert ops when any stand's queue exceeds 15 people AND transaction rate drops below baseline simultaneously — the combination flags a throughput problem, not just demand

---

## SUCCESS CRITERIA

By the end of this module, you should have:

✅ Spotted the queue anomaly from the live sensor data  
✅ Proved it's not normal by comparing to historical baselines  
✅ Quantified the revenue loss (~$880 at halftime alone)  
✅ Identified three contributing factors: equipment failure, missing staff, absent supervisor  
✅ Confirmed the finding with fan sentiment and identified walk-away revenue loss  
✅ Built the causal chain connecting all six data sources  
✅ Generated at least two visualizations (queue comparison chart, revenue bar chart)  
✅ Produced a management-ready PDF report  

---

## BONUS CHALLENGES (If Time Permits)

**1. Project the season cost:**
> If this same combination of problems hit every home game this season, what's the total revenue at risk? Assume 9 home games and use today's halftime as the baseline incident.

**2. Model a fix:**
> If we added a third staff member to Section 114 for halftime, how much would wait time drop? At what queue length does that extra labor cost pay for itself in recovered transactions?

**3. Find the walk-away count:**
> Based on the fan feedback and the gap between expected and actual transactions, estimate how many people abandoned the line without spending today. Put a dollar figure on the abandonment specifically.

**4. Was pulling the supervisor the right call?**
> The supervisor left Section 114 to help the beer stand. Pull up the queue and sales data for the Section 114 beer stand. Was that call actually justified — or did it make a bad situation worse?

---

## DATA FIELD REFERENCE

*(For reference — you don't need to use field names in your prompts. Just describe what you want in plain English.)*

**Live sensor feed:** real-time people in line, wait time in seconds, percentile rank vs. similar stands, sensor type

**Historical queues:** queue depth and wait time by stand, game, and period — your baseline for "is this normal"

**Sales data:** transactions, units sold, and revenue by stand and period — connects queue problems to dollars

**Staffing:** scheduled vs. actual headcount, supervisor presence, incident notes — the human side of the story

**Inventory/equipment:** stock levels, restock timing, equipment status flags, incident notes — where the root cause lives

**Fan feedback:** star ratings, perceived wait times, verbatim comments — validates findings and surfaces walk-away revenue

---

## NOTES FOR FACILITATORS

**The "Aha" moments to watch for:**
1. Live sensor data flags the anomaly — but doesn't explain it
2. Historical comparison proves today is genuinely abnormal, not just a busy halftime
3. Sales data converts an operational problem into a financial one — this is when the room pays attention
4. Staffing shows contributing factors but feels incomplete ("that's not enough to cause *this*")
5. Equipment data delivers the smoking gun — the warmer failure ties everything together
6. Fan feedback validates it all and surfaces walk-away revenue the POS data misses entirely

**If trainees get stuck:**
- Phase 2: Ask "what did the burger stand's line look like at halftime in Games 1 and 2?"
- Phase 4: Ask "was there a supervisor at Section 114 when this was happening?"
- Phase 5: Ask "look at the notes in the inventory data — anything jump out?"
- Phase 7: Suggest asking for a side-by-side comparison table of both stands

**Expected conclusion:**
A cheese sauce warming unit failure at 14:08, compounded by a staff no-show and a supervisor pulled to another location without a replacement, reduced Section 114 hot dog throughput by 41% during peak halftime demand — costing an estimated $880+ in lost revenue and generating the lowest fan satisfaction scores of the season. The burger stand, which pre-staged inventory and maintained full supervision, sailed through halftime unaffected and absorbed some of the overflow crowd. The incident was entirely preventable with a pre-game equipment checklist and a staffing contingency protocol.
